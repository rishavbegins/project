package com.Payroll.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Payroll.Entity.*;

public interface Salary_Repository extends JpaRepository<Salary, Long> {

}
