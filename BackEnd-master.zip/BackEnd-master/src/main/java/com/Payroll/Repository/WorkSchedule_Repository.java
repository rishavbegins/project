package com.Payroll.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Payroll.Entity.*;

public interface WorkSchedule_Repository extends JpaRepository<WorkSchedule, Long> {

}