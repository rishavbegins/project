package com.Payroll.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Payroll.Entity.Leave;

public interface Leave_Repository extends JpaRepository<Leave, Long> {

}
