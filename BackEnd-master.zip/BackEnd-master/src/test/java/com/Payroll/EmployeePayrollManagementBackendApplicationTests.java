package com.Payroll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeePayrollManagementBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
